package com.example.washingthecars;


import androidx.appcompat.app.AppCompatActivity;

import android.app.DatePickerDialog;
import android.app.TimePickerDialog;
import android.content.Intent;
import android.content.pm.ActivityInfo;
import android.os.Bundle;
import android.text.Editable;
import android.text.InputType;

import android.text.TextWatcher;
import android.view.View;

import android.widget.Button;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.TimePicker;


import java.text.SimpleDateFormat;
import java.util.Calendar;


public class TimeDate extends AppCompatActivity {
    EditText date_in;
    EditText time_in;
    TimePickerDialog timePickerDialog;
    Calendar calendar;
    int currentHour;
    int currentMinute;
    String amPm;
    Button move;
    public static final String STATION = "STATION";
    public static final String ADDRESS = "ADDRESS";
    private TextView text1,text2;
    private String stationName;
    private String stationAddress;
    EditText time,date;
    String stationTime,stationDate;
    Button bookingBtn;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_time_date);


        time = findViewById(R.id.time_input);
        date = findViewById(R.id.date_input);
        bookingBtn = findViewById(R.id.booking_btn);
        bookingBtn.setOnClickListener(new View.OnClickListener() {

            @Override
           public void onClick(View view) {
                sendData();
                Intent intent = new Intent(TimeDate.this, OrderHistoryActivity.class);
                intent.putExtra(OrderHistoryActivity.TIME,stationTime);
                intent.putExtra(OrderHistoryActivity.DATE,stationDate);
               intent.putExtra(OrderHistoryActivity.STATION,stationName);
               intent.putExtra(OrderHistoryActivity.ADDRESS,stationAddress);
               startActivity(intent);
            }
       });
        time.addTextChangedListener(loginTextWatcher);
        date.addTextChangedListener(loginTextWatcher);



        text1 = findViewById(R.id.textView1);
        text2 = findViewById(R.id.textView2);
        Intent intent = getIntent();
        stationName = intent.getStringExtra(STATION);
        stationAddress = intent.getStringExtra(ADDRESS);
        text1.setText(stationName);
        text2.setText(stationAddress);
//        move = findViewById(R.id.activity_booking_proceed_to_payment_btn);
//        move.setOnClickListener(new View.OnClickListener() {
//
//            @Override
//            public void onClick(View view) {
//                Intent intent = new Intent(TimeDate.this, PaymentBooking.class);
//                startActivity(intent);
//            }
//        });


        date_in = findViewById(R.id.date_input);
        time_in = findViewById(R.id.time_input);

        date_in.setInputType(InputType.TYPE_NULL);
        time_in.setInputType(InputType.TYPE_NULL);
        date_in.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v) {
                showDateDialog(date_in);

            }
        });
        time_in.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                calendar = Calendar.getInstance();
                currentHour = calendar.get(Calendar.HOUR_OF_DAY);
                currentMinute = calendar.get(Calendar.MINUTE);

                timePickerDialog = new TimePickerDialog(TimeDate.this, new TimePickerDialog.OnTimeSetListener() {
                    @Override
                    public void onTimeSet(TimePicker timePicker, int hourOfDay, int minutes) {
                        if (hourOfDay >= 12) {
                            amPm = "PM";
                        } else {
                            amPm = "AM";
                        }
                        time_in.setText(String.format("%02d:%02d", hourOfDay, minutes) + amPm);
                    }
                }, currentHour, currentMinute, false);

                timePickerDialog.show();
            }
        });


    }
    private TextWatcher loginTextWatcher = new TextWatcher() {
        @Override
        public void beforeTextChanged(CharSequence s, int start, int count, int after) {

        }

        @Override
        public void onTextChanged(CharSequence s, int start, int before, int count) {
            stationTime = time.getText().toString();
            stationDate = date.getText().toString();

            bookingBtn.setEnabled(!stationTime.isEmpty() && !stationDate.isEmpty());
        }

        @Override
        public void afterTextChanged(Editable s) {

        }
    };

    private void sendData() {
        stationTime = time.getText().toString();
        stationDate = date.getText().toString();
    }


    private void showDateDialog(EditText date_in) {
        Calendar calendar = Calendar.getInstance();
        DatePickerDialog.OnDateSetListener dateSetListener = new DatePickerDialog.OnDateSetListener(){

            @Override
            public void onDateSet(DatePicker datePicker, int year, int month, int dayofMonth) {
                calendar.set(Calendar.YEAR,year);
                calendar.set(Calendar.MONTH,month);
                calendar.set(Calendar.DAY_OF_MONTH,dayofMonth);
                SimpleDateFormat simpleDateFormat = new SimpleDateFormat("yy/MM/dd");

                date_in.setText(simpleDateFormat.format(calendar.getTime()));

            }
        };
        new DatePickerDialog(TimeDate.this, dateSetListener,calendar.get(Calendar.YEAR),calendar.get(Calendar.MONTH),calendar.get(Calendar.DAY_OF_MONTH)).show();
    }

}
