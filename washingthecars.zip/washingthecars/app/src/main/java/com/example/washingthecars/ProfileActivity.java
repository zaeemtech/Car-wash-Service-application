package com.example.washingthecars;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.cardview.widget.CardView;

import android.annotation.SuppressLint;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.ActivityInfo;
import android.icu.text.Normalizer2;
import android.net.Uri;
import android.os.Bundle;

import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.inputmethod.InputMethodManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Toast;

import com.github.drjacky.imagepicker.ImagePicker;
import com.google.android.material.bottomnavigation.BottomNavigationView;
import com.google.android.material.floatingactionbutton.FloatingActionButton;
import com.google.android.material.textfield.TextInputLayout;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import de.hdodenhof.circleimageview.CircleImageView;

public class ProfileActivity extends AppCompatActivity {
    FirebaseUser user;
    DatabaseReference reference;
    String userID;
    Button logout;

    ImageView cover;
    FloatingActionButton fab, changeProfile;
    CircleImageView profile;

    String _fullName, _phone, _email, _username, _password;

    EditText fullNameEd, emailEd, phoneNoEd, usernameEd;
    TextInputLayout passwordEd;
    // start code for clickable cardview
    public CardView card1, card2;
    // end code for clickable cardview

    @SuppressLint("NonConstantResourceId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_profile);
        this.setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_PORTRAIT);


        // start code for clickable cardview
        card1 = findViewById(R.id.balancecardview);
        card2 = findViewById(R.id.bookingcardview);

        card1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(ProfileActivity.this, OrderHistoryActivity.class);
                startActivity(intent);
            }
        });

        card2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(ProfileActivity.this, OrderHistoryActivity.class);
                startActivity(intent);
            }
        });

        // end code for clickable cardview


        BottomNavigationView bottomNavigationView = findViewById(R.id.bottomNavigationView);
        bottomNavigationView.setSelectedItemId(R.id.User);

        logout = findViewById(R.id.prof_logout);
        logout.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View view) {
               FirebaseAuth.getInstance().signOut();
               startActivity(new Intent(ProfileActivity.this,MainActivity.class));
            }
        });

        bottomNavigationView.setOnItemSelectedListener(item -> {
            int id = item.getItemId();
            switch (id){
                case R.id.Maps:
                    startActivity(new Intent(getApplicationContext(), MapsActivity.class));
                    overridePendingTransition(0,0);
                    return true;
                case R.id.StationList:
                    startActivity(new Intent(getApplicationContext(), Stationlist.class));
                    overridePendingTransition(0,0);
                    return true;
                case R.id.User:
                    return true;
            }
            return false;
        });


//        Button logout = findViewById(R.id.signOut);
//
//        logout.setOnClickListener(v -> {
//            FirebaseAuth.getInstance().signOut();
//            ProfileActivity.this.startActivity(new Intent(ProfileActivity.this, MainActivity.class));
//
//        });

        user = FirebaseAuth.getInstance().getCurrentUser();
        reference = FirebaseDatabase.getInstance().getReference("Users");
        userID = user.getUid();

          fullNameEd = findViewById(R.id.prof_name);
          emailEd = findViewById(R.id.prof_email);
          phoneNoEd = findViewById(R.id.prof_phone);
          usernameEd = findViewById(R.id.prof_username);
          passwordEd = findViewById(R.id.prof_password);

        reference.child(userID).addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                User userProfile = snapshot.getValue(User.class);

                if (userProfile != null) {
                    _fullName = userProfile.fullName;
                    _email = userProfile.email;
                    _phone = userProfile.phone;
                    _username = userProfile.username;
                    _password = userProfile.password;

                    fullNameEd.setText(_fullName);
                    emailEd.setText(_email);
                    phoneNoEd.setText(_phone);
                    usernameEd.setText(_username);
                    passwordEd.getEditText().setText(_password);
                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {
                Toast.makeText(ProfileActivity.this,"Something went wrong!",Toast.LENGTH_SHORT).show();

            }
        });

        EditText et1 = findViewById(R.id.prof_username);
        et1.setOnFocusChangeListener(new View.OnFocusChangeListener() {

            @Override
            public void onFocusChange(View view, boolean b) {
                InputMethodManager imm = (InputMethodManager) getSystemService(Context.INPUT_METHOD_SERVICE);
                imm.hideSoftInputFromWindow(view.getWindowToken(),0);
            }
        });

        cover = findViewById(R.id.profile_backgroundimg);
        fab = findViewById(R.id.backimgfloat);

        changeProfile = findViewById(R.id.prof_imgfloat);
        profile = findViewById(R.id.profile_img);

        fab.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                ImagePicker.Companion.with(ProfileActivity.this)
                        .crop()
//                        .cropOval()
                        .compress(1024)
                        .maxResultSize(1080,1080)
                        .start(10);
            }
        });

        changeProfile.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                ImagePicker.Companion.with(ProfileActivity.this)
                        .crop()
                        .cropOval()
                        .compress(1024)
                        .maxResultSize(1080,1080)
                        .start(20);
            }
        });


    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if(requestCode==10){
            Uri uri = data.getData();
            cover.setImageURI(uri);
        }else{
            Uri uri = data.getData();
            profile.setImageURI(uri);
        }

    }

    //start code for update the profile data
    public void update(View view){

        if(isNameChanged() || isPhoneChanged() || isEmailChanged() || isPasswordChanged() ){
            Toast.makeText(this,"Data has been Updated!",Toast.LENGTH_LONG).show();
        }
        else{
            Toast.makeText(this,"Data is same and can't be updated",Toast.LENGTH_LONG).show();
        }
    }

    private boolean isPasswordChanged() {
        if(!_password.equals(passwordEd.getEditText().getText().toString())){
            reference.child(userID).child("password").setValue(passwordEd.getEditText().getText().toString());
            _password = passwordEd.getEditText().getText().toString();
            return true;
        }
        else{
            return false;
        }
    }

    private boolean isEmailChanged() {
        if(!_email.equals(emailEd.getText().toString())){
            reference.child(userID).child("email").setValue(emailEd.getText().toString());
            _email = emailEd.getText().toString();
            return true;
        }
        else{
            return false;
        }
    }

    private boolean isPhoneChanged() {
        if(!_phone.equals(phoneNoEd.getText().toString())){
            reference.child(userID).child("phone").setValue(phoneNoEd.getText().toString());
            _phone = phoneNoEd.getText().toString();
            return true;
        }
        else{
            return false;
        }
    }

    private boolean isNameChanged() {
        if(!_fullName.equals(fullNameEd.getText().toString())){
        reference.child(userID).child("fullName").setValue(fullNameEd.getText().toString());
        _fullName = fullNameEd.getText().toString();
        return true;
        }
        else{
            return false;
        }
    }
    //end code for update the profile data

    //start of code for option menu in profile

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.optionmenu_prof, menu);
        return super.onCreateOptionsMenu(menu);
    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        if (item.getItemId() == R.id.setp) {
            Intent i = new Intent(this, Preference.class);
            startActivity(i);
        }
        if (item.getItemId() == R.id.ext){
            this.finishAffinity();
        }
        return super.onOptionsItemSelected(item);

    }
    // end of code for option menu in profile


}