package com.example.washingthecars;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;

import android.Manifest;
import android.content.Intent;
import android.content.pm.ActivityInfo;
import android.content.pm.PackageManager;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.os.Bundle;
import android.os.Environment;
import android.text.format.DateFormat;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import java.io.File;
import java.io.FileOutputStream;
import java.util.Calendar;
import java.util.Date;

public class OrderHistoryActivity extends AppCompatActivity {
    public static final String TIME = "TIME";
    public static final String DATE = "DATE";
    public static final String STATION = "STATION";
    public static final String ADDRESS = "ADDRESS";
    private TextView text1,text2,text3,text4;
    private String stationTime;
    private String stationDate;
    private String stationName;
    private String stationAddress;
    Button Done;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_order_history);



        Done = findViewById(R.id.Done);
        Done.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent i = new Intent(OrderHistoryActivity.this,BookingConfirmationActivity.class);
                startActivity(i);
            }
        });

        text1 = findViewById(R.id.textView1);
        text2 = findViewById(R.id.textView2);
        text3 = findViewById(R.id.textView3);
        text4 = findViewById(R.id.textView4);

        Intent intent = getIntent();


        stationTime = intent.getStringExtra(TIME);
        stationDate = intent.getStringExtra(DATE);
        text1.setText(stationTime);
        text2.setText(stationDate);
        stationName = intent.getStringExtra(STATION);
        stationAddress = intent.getStringExtra(ADDRESS);
        text3.setText(stationName);
        text4.setText(stationAddress);

        //START to take screenshot
        ActivityCompat.requestPermissions(this,
                new String[]{Manifest.permission.WRITE_EXTERNAL_STORAGE,
                Manifest.permission.READ_EXTERNAL_STORAGE},
                PackageManager.PERMISSION_GRANTED);
        //END TO take screenshot

    }
    public void buttonScreenshot(View view){
//        View view1 = view.getRootView();
       View view1 = getWindow().getDecorView().getRootView();

        Bitmap bitmap = Bitmap.createBitmap(view1.getWidth(), view1.getHeight(), Bitmap.Config.ARGB_8888);
        Canvas canvas = new Canvas(bitmap);
        view1.draw(canvas);
        File fileScreenshot = new File(this.getExternalFilesDir(Environment.DIRECTORY_PICTURES),
                Calendar.getInstance().getTime().toString()+ ".jpg");

        try{
            FileOutputStream fileOutputStream = new FileOutputStream(fileScreenshot);
            bitmap.compress(Bitmap.CompressFormat.JPEG, 100, fileOutputStream);
            fileOutputStream.flush();
            fileOutputStream.close();
            Toast.makeText(this, "A ScreenShot of Booking has Been Saved in Your Device", Toast.LENGTH_LONG).show();
            if(fileScreenshot.exists()){

            }

        }
        catch(Exception e){
            Toast.makeText(this, "Booking Failed!", Toast.LENGTH_SHORT).show();

        }
    }
}