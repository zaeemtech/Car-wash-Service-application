package com.example.washingthecars;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.content.pm.ActivityInfo;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

import com.google.android.material.floatingactionbutton.FloatingActionButton;

import java.util.ArrayList;
import java.util.List;

public class ListStation5 extends AppCompatActivity {
    RecyclerView recyclerView;
    LinearLayoutManager layoutManager;
    List<ModelClass> userList;
    Adapter adapter;
    Button move;
    //Start of code for dialing call
    FloatingActionButton buttonCall;
    // end of code for dialing call
    EditText station,address;
    String stationName,stationAddress;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_list_station5);

        //Start of code for dialing call
        buttonCall = findViewById(R.id.fabcall);
        station = findViewById(R.id.edittext1);
        address = findViewById(R.id.edittext2);
        station.setEnabled(false);
        address.setEnabled(false);
        // end of code for dialing call        //Start of code for dialing call
        //        buttonCall = findViewById(R.id.fabcall);
        //        // end of code for dialing call

        move = findViewById(R.id.liststationbut5);
        move.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View view) {
                sendData();
                Intent intent = new Intent(ListStation5.this, TimeDate.class);
                intent.putExtra(TimeDate.STATION,stationName);
                intent.putExtra(TimeDate.ADDRESS,stationAddress);
                startActivity(intent);
            }
        });
        //this is the start of the code for the recycler view in the station list activity
        initData();
        initRecyclerView();
        //this is the end of the code for the recycler view in the station list activity
        //Start of code for dialing call
        buttonCall.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(Intent.ACTION_DIAL);
                intent.setData(Uri.parse("tel:03211401180"));
                startActivity(intent);
            }
        });
        // end of code for dialing call
    }

    private void sendData() {
        stationName = station.getText().toString();
        stationAddress = address.getText().toString();
    }

    private void initData() {
        userList = new ArrayList<>();
        userList.add(new ModelClass(R.drawable.ic_baseline_person_24,R.drawable.starfour14080,"employee1","Polish"," "));
        userList.add(new ModelClass(R.drawable.ic_baseline_person_24,R.drawable.starfour14080,"employee2","Interior Wash"," "));
        userList.add(new ModelClass(R.drawable.ic_baseline_person_24,R.drawable.starfour14080,"employee3","Body Wash"," "));
        userList.add(new ModelClass(R.drawable.ic_baseline_person_24,R.drawable.starfour14080,"employee4","Repair"," "));
        userList.add(new ModelClass(R.drawable.ic_baseline_person_24,R.drawable.starfour14080,"employee5","Mechanic"," "));
        userList.add(new ModelClass(R.drawable.ic_baseline_person_24,R.drawable.starfour14080,"employee6","Body Wash"," "));
        userList.add(new ModelClass(R.drawable.ic_baseline_person_24,R.drawable.starfour14080,"employee7","Polish"," "));
        userList.add(new ModelClass(R.drawable.ic_baseline_person_24,R.drawable.starfour14080,"employee8","Interior Wash"," "));
        userList.add(new ModelClass(R.drawable.ic_baseline_person_24,R.drawable.starfour14080,"employee9","Mechanic"," "));
        userList.add(new ModelClass(R.drawable.ic_baseline_person_24,R.drawable.starfour14080,"employee10","Polish"," "));
    }

    //this is the start of the code for the recycler view in the station list activity
    @SuppressLint("NotifyDataSetChanged")
    private void initRecyclerView() {
        recyclerView = findViewById(R.id.recyclerView);
        layoutManager = new LinearLayoutManager(this);
        layoutManager.setOrientation(RecyclerView.VERTICAL);
        recyclerView.setLayoutManager(layoutManager);
        adapter = new Adapter(userList);
        recyclerView.setAdapter(adapter);
        adapter.notifyDataSetChanged();

    }
}