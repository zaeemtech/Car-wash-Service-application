package com.example.washingthecars;

import androidx.annotation.NonNull;
import androidx.fragment.app.FragmentActivity;


import android.Manifest;
import android.annotation.SuppressLint;

import android.app.Dialog;
import android.content.DialogInterface;
import android.content.Intent;

import android.net.Uri;
import android.os.Bundle;
import android.provider.Settings;

import android.widget.Toast;

import com.google.android.gms.common.ConnectionResult;
import com.google.android.gms.common.GoogleApiAvailability;
import com.google.android.gms.maps.CameraUpdate;
import com.google.android.gms.maps.CameraUpdateFactory;
import com.google.android.gms.maps.GoogleMap;

import com.google.android.gms.maps.OnMapReadyCallback;
import com.google.android.gms.maps.SupportMapFragment;

import com.example.washingthecars.databinding.ActivityMapsBinding;

import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.MarkerOptions;
import com.google.android.material.bottomnavigation.BottomNavigationView;
import com.karumi.dexter.Dexter;
import com.karumi.dexter.PermissionToken;
import com.karumi.dexter.listener.PermissionDeniedResponse;
import com.karumi.dexter.listener.PermissionGrantedResponse;
import com.karumi.dexter.listener.PermissionRequest;
import com.karumi.dexter.listener.single.PermissionListener;



public class MapsActivity extends FragmentActivity implements OnMapReadyCallback {

    //it starts here to get location on map
    boolean isPermissionGranter;
    //it end hereto get location on map

    GoogleMap googleMap;
    private ActivityMapsBinding binding;
    SupportMapFragment supportMapFragment;




    @SuppressLint("NonConstantResourceId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);


        //it starts here to get location on map
        checkPermission();
        if(isPermissionGranter){
            if(checkGooglePlayServices()){
                Toast.makeText(this,"Google PlayServices Available", Toast.LENGTH_SHORT).show();
            }else{
                Toast.makeText(this,"Google Play Services Not Available", Toast.LENGTH_SHORT).show();
            }
        }


        binding = ActivityMapsBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());
        supportMapFragment = (SupportMapFragment) getSupportFragmentManager()
                .findFragmentById(R.id.map);
        assert supportMapFragment != null;
        supportMapFragment.getMapAsync(this);

        // Obtain the SupportMapFragment and get notified when the map is ready to be used.




        //code for bottom navigation
        BottomNavigationView bottomNavigationView = findViewById(R.id.bottomNavigationView);
        bottomNavigationView.setSelectedItemId(R.id.Maps);

        bottomNavigationView.setOnItemSelectedListener(item -> {
            int id = item.getItemId();
            switch (id) {
                case R.id.Maps:
                    return true;
                case R.id.StationList:
                    startActivity(new Intent(getApplicationContext(), Stationlist.class));
                    overridePendingTransition(0, 0);
                    return true;
                case R.id.User:
                    startActivity(new Intent(getApplicationContext(), ProfileActivity.class));
                    overridePendingTransition(0, 0);
                    return true;
            }
            return false;
        });


    }
    //it starts here to get location on map
    private boolean checkGooglePlayServices(){
        GoogleApiAvailability googleApiAvailability =  GoogleApiAvailability.getInstance();
        int result = googleApiAvailability.isGooglePlayServicesAvailable(this);
        if(result == ConnectionResult.SUCCESS) {
            return true;
        }else if (googleApiAvailability.isUserResolvableError(result)){
            Dialog dialog = googleApiAvailability.getErrorDialog(this, result, 201, new DialogInterface.OnCancelListener() {
                @Override
                public void onCancel(DialogInterface dialogInterface) {
                    Toast.makeText(MapsActivity.this, "User Cancelled Dialogue",Toast.LENGTH_SHORT).show();
                }
            });
            assert dialog != null;
            dialog.show();
        }
        return false;
    }
    //it end here to get location on map


    //it starts here to get location on map


    private void checkPermission(){
        Dexter.withContext(this).withPermission(Manifest.permission.ACCESS_FINE_LOCATION).withListener(new PermissionListener() {
            @Override
            public void onPermissionGranted(PermissionGrantedResponse permissionGrantedResponse) {
                isPermissionGranter = true;
                Toast.makeText(MapsActivity.this, "Permission Granted",Toast.LENGTH_SHORT).show();
            }

            @Override
            public void onPermissionDenied(PermissionDeniedResponse permissionDeniedResponse) {
                Intent intent = new Intent();
                intent.setAction(Settings.ACTION_APPLICATION_DETAILS_SETTINGS);
                Uri uri = Uri.fromParts("package", getPackageName(),"");
                intent.setData(uri);
                startActivity(intent);
            }

            @Override
            public void onPermissionRationaleShouldBeShown(PermissionRequest permissionRequest, PermissionToken permissionToken) {
                permissionToken.continuePermissionRequest();
            }
        }).check();
    }
    //it end hereto get location on map

    @SuppressLint("MissingPermission")
    @Override
    public void onMapReady(@NonNull GoogleMap map) {

        //it starts here to get location on map
        //the code to create the markers on the screen starts here
        googleMap = map;
        LatLng latlng = new LatLng(31.543224495833282, 74.37138256052677);
        MarkerOptions markerOptions = new MarkerOptions();
        markerOptions.title("station 1 ");
        markerOptions.snippet("gujranwala, bhatii chownk, f block" + "| 4.4 ⭐");
        markerOptions.position(latlng);
        googleMap.addMarker(markerOptions);

        LatLng latlng1 = new LatLng(31.539222910633743, 74.42027431269454);
        MarkerOptions markerOptions1 = new MarkerOptions();
        markerOptions1.title("station 2 ");
        markerOptions1.snippet("sialkot, c block, al faisal town"+ "| 4.1 ⭐");
        markerOptions1.position(latlng1);
        googleMap.addMarker(markerOptions1);

        LatLng latlng2 = new LatLng(31.554578408089142, 74.38568517321278);
        MarkerOptions markerOptions2 = new MarkerOptions();
        markerOptions2.title("station 3 ");
        markerOptions2.snippet("sialkot, c block, al faisal town"+ "| 3.1 ⭐");
        markerOptions2.position(latlng2);
        googleMap.addMarker(markerOptions2);

        LatLng latlng3 = new LatLng(31.499997356186086, 74.41400179745165);
        MarkerOptions markerOptions3 = new MarkerOptions();
        markerOptions3.title("station 4 ");
        markerOptions3.snippet("sialkot, c block, al faisal town"+ "| 5.0 ⭐");
        markerOptions3.position(latlng3);
        googleMap.addMarker(markerOptions3);

        LatLng latlng4 = new LatLng(31.506290855452658, 74.45811877064793);
        MarkerOptions markerOptions4 = new MarkerOptions();
        markerOptions4.title("station 5 ");
        markerOptions4.snippet("sialkot, c block, al faisal town"+ "| 4.9 ⭐");
        markerOptions4.position(latlng4);
        googleMap.addMarker(markerOptions4);

        LatLng latlng5 = new LatLng(31.55413685982394, 74.42824969152807);
        MarkerOptions markerOptions5 = new MarkerOptions();
        markerOptions5.title("station 6 ");
        markerOptions5.snippet("sialkot, c block, al faisal town"+ "| 3.6 ⭐");
        markerOptions5.position(latlng5);
        googleMap.addMarker(markerOptions5);

        LatLng latlng6 = new LatLng(31.47042687393033, 74.33229098332117);
        MarkerOptions markerOptions6 = new MarkerOptions();
        markerOptions6.title("station 7 ");
        markerOptions6.snippet("sialkot, c block, al faisal town"+ "| 4.5 ⭐");
        markerOptions6.position(latlng6);
        googleMap.addMarker(markerOptions6);

        LatLng latlng7 = new LatLng(31.533655332882372, 74.41211352234838);
        MarkerOptions markerOptions7 = new MarkerOptions();
        markerOptions7.title("station 8 ");
        markerOptions7.snippet("sialkot, c block, al faisal town"+ "| 3.7 ⭐");
        markerOptions7.position(latlng7);
        googleMap.addMarker(markerOptions7);

        LatLng latlng8 = new LatLng(31.546483958032034, 74.40613266665835);
        MarkerOptions markerOptions8 = new MarkerOptions();
        markerOptions8.title("station 9 ");
        markerOptions8.snippet("sialkot, c block, al faisal town"+ "| 4.7 ⭐");
        markerOptions8.position(latlng8);
        googleMap.addMarker(markerOptions8);

        LatLng latlng9 = new LatLng(31.573467065201793, 74.3957211154573);
        MarkerOptions markerOptions9 = new MarkerOptions();
        markerOptions9.title("station 10 ");
        markerOptions9.snippet("sialkot, c block, al faisal town"+ "| 4.8 ⭐");
        markerOptions9.position(latlng9);
        googleMap.addMarker(markerOptions9);
        //the code to create markers on the map screen ends here


        CameraUpdate cameraUpdate = CameraUpdateFactory.newLatLngZoom(latlng,12);
        //it end here to get location on map

        //it starts here to get zoom control on map
        googleMap.getUiSettings().setZoomControlsEnabled(true);
        //it end here to get zoom control on map

        //it starts here to get location on map
        googleMap.setMyLocationEnabled(true);
        //it end here to get location on map




    }


//    //the start of types of maps option it connected with menu folder inside menumap
//    @Override
//    public boolean onCreateOptionsMenu(Menu menu){
//        getMenuInflater().inflate(R.menu.menumap, menu);
//        return true;
//    }
//    @Override
//    public boolean onOptionsItemSelected(MenuItem item){
//        if(item.getItemId()==R.id.noneMap){
//            googleMap.setMapType(GoogleMap.MAP_TYPE_NONE);
//        }
//        if(item.getItemId()==R.id.NormalMap){
//            googleMap.setMapType(GoogleMap.MAP_TYPE_NORMAL);
//        }
//        if(item.getItemId()==R.id.SatelliteMap){
//            googleMap.setMapType(GoogleMap.MAP_TYPE_SATELLITE);
//        }
//        if(item.getItemId()==R.id.MapHybrid){
//            googleMap.setMapType(GoogleMap.MAP_TYPE_HYBRID);
//        }
//        if(item.getItemId()==R.id.MapTerrain){
//            googleMap.setMapType(GoogleMap.MAP_TYPE_TERRAIN);
//        }
//        return super.onOptionsItemSelected(item);
//    }
//    //the end of types of maps option it connected with menu folder inside menumap
}