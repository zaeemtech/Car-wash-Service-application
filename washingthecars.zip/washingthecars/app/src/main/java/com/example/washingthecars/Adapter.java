package com.example.washingthecars;


import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Filter;
import android.widget.Filterable;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.cardview.widget.CardView;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;
import java.util.List;

public class Adapter extends RecyclerView.Adapter<Adapter.ViewHolder> implements Filterable{
    //this is the start of the code for the recycler view in the station list activty
    public List<ModelClass> userList;

    //Start of search view on action bar default
    public List<ModelClass> userListAll;
    // End of search view on action bar default


    public Adapter (List<ModelClass> userList) {

        this.userList = userList;

        //Start of search view on action bar default
        this.userListAll = new ArrayList<>(userList);
        // End of search view on action bar default

        }
    @NonNull
    @Override
    public Adapter.ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.item_design,parent,false);
        return new ViewHolder(view);
    }


    @Override
    public void onBindViewHolder(@NonNull Adapter.ViewHolder holder, int position) {
        int resource = userList.get(position).getStationimage();
        int resource1 = userList.get(position).getStationratng();
        String name = userList.get(position).getStationtitle();
        String msg = userList.get(position).getStationdescription();
        String line = userList.get(position).getDivider();

        holder.setData(resource,resource1,name,msg,line);
        //animation for the recycler view
//        holder.cardView.startAnimation(AnimationUtils.loadAnimation(holder.itemView.getContext(), R.anim.recycleranim));
    }

    @Override
    public int getItemCount() {
        return userList.size();
    }


    //Start of search view on action bar default
    @Override
    public Filter getFilter() {
        return filter;
    }
    Filter filter = new Filter() {
        //run on background thread
        @Override
        protected FilterResults performFiltering(CharSequence charSequence) {
            List<ModelClass> filteredList = new ArrayList<>();
            if(charSequence ==null || charSequence.length() == 0){
                filteredList.addAll(userListAll);
            }else{
                String filterPattern = charSequence.toString().toLowerCase().trim();

                for(ModelClass item: userListAll) {
                    if(item.getStationtitle().toLowerCase().contains(filterPattern)){
                        filteredList.add(item);
                    }

                }

                }
            FilterResults results = new FilterResults();
            results.values = filteredList;
            return results;
        }
        //run on a ui thread
        @Override
        protected void publishResults(CharSequence charSequence, FilterResults results) {
            userList.clear();
            userList.addAll((List) results.values);
            notifyDataSetChanged();

        }
    };

    // End of search view on action bar default


    public static class ViewHolder extends RecyclerView.ViewHolder{
        private final ImageView imageView1;
        private final ImageView imagerating;
        private final TextView texttitle;
        private final TextView textdescription;
        private final TextView division;
        CardView cardView;
        private List<ModelClass> userList;

        public ViewHolder(@NonNull View itemView) {
            super(itemView);
            imageView1 = itemView.findViewById(R.id.stationimage);
            imagerating = itemView.findViewById(R.id.stationrating);
            texttitle = itemView.findViewById(R.id.stationtitle);
            textdescription = itemView.findViewById(R.id.stationdescription);
            division = itemView.findViewById(R.id.divider);
        }


        public void setData(int resource, int resource1, String name, String msg, String line) {
            imageView1.setImageResource(resource);
            imagerating.setImageResource(resource1);
            texttitle.setText(name);
            textdescription.setText(msg);
            division.setText(line);
        }
    }

}
//this is the end of the code for the recycler view in the station list activty