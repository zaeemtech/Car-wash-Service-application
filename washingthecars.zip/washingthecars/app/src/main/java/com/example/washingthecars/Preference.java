package com.example.washingthecars;

import android.content.SharedPreferences;
import android.graphics.Color;
import android.os.Bundle;
import android.os.PersistableBundle;
import android.preference.PreferenceActivity;

import androidx.annotation.Nullable;
import androidx.preference.CheckBoxPreference;
import androidx.preference.PreferenceManager;

public class Preference extends PreferenceActivity{
    @Override
    public void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        addPreferencesFromResource(R.xml.prefs);
    }
//    private void load_settung(){
//        SharedPreferences sp = PreferenceManager.getDefaultSharedPreferences(this);
//        boolean chk_night = sp.getBoolean("NIGHT",false);
//        if(chk_night){
//            getListView().setBackgroundColor(Color.parseColor("#222222"));
//        }else{
//            getListView().setBackgroundColor(Color.parseColor("#ffffff"));
//
//        }
//    }
}
