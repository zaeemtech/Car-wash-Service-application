package com.example.washingthecars;


import android.annotation.SuppressLint;
import android.content.Intent;
import android.content.pm.ActivityInfo;
import android.os.Bundle;

import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.view.inputmethod.EditorInfo;


import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.SearchView;
import androidx.appcompat.widget.Toolbar;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;


import com.google.android.material.bottomnavigation.BottomNavigationView;
import com.google.android.material.floatingactionbutton.FloatingActionButton;

import java.util.ArrayList;
import java.util.List;

import kotlin.Lazy;

public class Stationlist<val> extends AppCompatActivity {
    //this is the start of the code for the recycler view in the station list activity
    RecyclerView recyclerView;
    LinearLayoutManager layoutManager;
    List<ModelClass> userList;
    Adapter adapter;
    FloatingActionButton floatingactionbutton;

    //the start of animation for 3 float action button
    FloatingActionButton fab, fab2 , fab1;
    Animation fabOpen, fabClose, rotateForward, rotateBackward;
    boolean isOpen = false;

    //the start of animation for 3 float action button



    @SuppressLint("NonConstantResourceId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_stationlist);


        //the start of animation for 3 float action button
        fab = findViewById(R.id.floatmenu);
        fab1 = findViewById(R.id.floattowhatsapp);
        fab2 = findViewById(R.id.floattosms);
        //animations
        fabOpen = AnimationUtils.loadAnimation(this,R.anim.fab_open);
        fabClose = AnimationUtils.loadAnimation(this,R.anim.fab_close);

        rotateForward = AnimationUtils.loadAnimation(this,R.anim.fab_rotate_forward);
        rotateBackward = AnimationUtils.loadAnimation(this,R.anim.fab_rotate_backward);

        //set click listener on fab menu
        fab.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                animateFab();

            }
        });

        //the start of animation for 3 float action button

        //Start of code for floating action button to new activity

        fab2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(Stationlist.this, MessageActivity.class);
                startActivity(intent);
            }
        });
        fab1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(Stationlist.this, WhatsappActivity.class);
                startActivity(intent);
            }
        });
        //End of code for floating action button to new activity


        //this is the end of the code for the recycler view in the station list activity


        BottomNavigationView bottomNavigationView = findViewById(R.id.bottomNavigationView);
        bottomNavigationView.setSelectedItemId(R.id.StationList);

        bottomNavigationView.setOnItemSelectedListener(item -> {
            int id = item.getItemId();
            switch (id) {
                case R.id.Maps:
                    startActivity(new Intent(getApplicationContext(), MapsActivity.class));
                    overridePendingTransition(0, 0);
                    return true;
                case R.id.StationList:
                    return true;
                case R.id.User:
                    startActivity(new Intent(getApplicationContext(), ProfileActivity.class));
                    overridePendingTransition(0, 0);
                    return true;
            }
            return false;
        });


        //this is the start of the code for the recycler view in the station list activity
        initData();
        initRecyclerView();
        //this is the end of the code for the recycler view in the station list activity

        recyclerView.addOnItemTouchListener(new RecyclerTouchListener(this, recyclerView, new RecyclerTouchListener.ClickListener() {
            @Override
            public void onClick(View view, int position) {
                switch (position) {
                    case 0:
                        Intent intent = new Intent(Stationlist.this, ListStation1.class);
                        startActivity(intent);
                        break;
                    case 1:
                        Intent intent1 = new Intent(Stationlist.this, ListStation2.class);
                        startActivity(intent1);
                        break;
                    case 2:
                        Intent intent2 = new Intent(Stationlist.this, ListStation3.class);
                        startActivity(intent2);
                        break;
                    case 3:
                        Intent intent3 = new Intent(Stationlist.this, ListStation4.class);
                        startActivity(intent3);
                        break;
                    case 4:
                        Intent intent4 = new Intent(Stationlist.this, ListStation5.class);
                        startActivity(intent4);
                        break;
                    case 5:
                        Intent intent5 = new Intent(Stationlist.this, ListStation6.class);
                        startActivity(intent5);
                        break;
                    case 6:
                        Intent intent6 = new Intent(Stationlist.this, ListStation7.class);
                        startActivity(intent6);
                        break;
                    case 7:
                        Intent intent7 = new Intent(Stationlist.this, ListStation8.class);
                        startActivity(intent7);
                        break;
                    case 8:
                        Intent intent8 = new Intent(Stationlist.this, ListStation9.class);
                        startActivity(intent8);
                        break;
                    case 9:
                        Intent intent9 = new Intent(Stationlist.this, ListStation10.class);
                        startActivity(intent9);
                        break;

                    default:
                }

            }

            @Override
            public void onLongClick(View view, int position) {

            }
        }));


    }
    //the start of animation for 3 float action button
    private void animateFab(){
        if (isOpen){
            fab.startAnimation(rotateForward);
            fab1.startAnimation(fabClose);
            fab2.startAnimation(fabClose);
            fab1.setClickable(false);
            fab2.setClickable(false);
            isOpen = false;
        }
        else{
            fab.startAnimation(rotateBackward);
            fab1.startAnimation(fabOpen);
            fab2.startAnimation(fabOpen);
            fab1.setClickable(true);
            fab2.setClickable(true);
            isOpen = true;
        }
    }

    //the start of animation for 3 float action button


    private void initData() {
        userList = new ArrayList<>();
        userList.add(new ModelClass(R.drawable.carwashstation1, R.drawable.starfour14080, "Ali Car Wash", "lahore", " "));
        userList.add(new ModelClass(R.drawable.carwashstation1, R.drawable.starfour14080, "Zubaid Car Wash", "karachi", " "));
        userList.add(new ModelClass(R.drawable.carwashstation1, R.drawable.starfour14080, "Shani Car Wash", "Gujranwala", "  "));
        userList.add(new ModelClass(R.drawable.carwashstation1, R.drawable.starfour14080, "Sheikh Car Wash", "Peshawar", " "));
        userList.add(new ModelClass(R.drawable.carwashstation1, R.drawable.starfour14080, "Lovely Car Wash", "lahore", " "));
        userList.add(new ModelClass(R.drawable.carwashstation1, R.drawable.starfour14080, "Gen. Car Wash", "karachi", " "));
        userList.add(new ModelClass(R.drawable.carwashstation1, R.drawable.starfour14080, "Pro Car Wash", "Islamabad", " "));
        userList.add(new ModelClass(R.drawable.carwashstation1, R.drawable.starfour14080, "Farzand Car Wash", "karachi", " "));
        userList.add(new ModelClass(R.drawable.carwashstation1, R.drawable.starfour14080, "Fabulous Car Wash", "lahore", " "));
        userList.add(new ModelClass(R.drawable.carwashstation1, R.drawable.starfour14080, "Bismillah Car Wash", "Faisalabad", " "));
    }

    //this is the start of the code for the recycler view in the station list activity
    @SuppressLint("NotifyDataSetChanged")
    private void initRecyclerView() {
        recyclerView = findViewById(R.id.recyclerView);
        layoutManager = new LinearLayoutManager(this);
        layoutManager.setOrientation(RecyclerView.VERTICAL);
        recyclerView.setLayoutManager(layoutManager);
        adapter = new Adapter(userList);
        recyclerView.setAdapter(adapter);
        adapter.notifyDataSetChanged();

    }

    //this is the end of the code for the recycler view in the station list activity

//Start of search view on action bar default
@Override
public boolean onCreateOptionsMenu(Menu menu) {
    getMenuInflater().inflate(R.menu.main_menu, menu);
    MenuItem item = menu.findItem(R.id.action_search);
    SearchView searchView = (SearchView) item.getActionView();
    searchView.setImeOptions(EditorInfo.IME_ACTION_DONE);
    searchView.setOnQueryTextListener(new SearchView.OnQueryTextListener() {
        @Override
        public boolean onQueryTextSubmit(String query) {
            return false;
        }

        @Override
        public boolean onQueryTextChange(String newText) {
            adapter.getFilter().filter(newText);
            return false;
        }
    });
    return true;
}
// End of search view on action bar default

}