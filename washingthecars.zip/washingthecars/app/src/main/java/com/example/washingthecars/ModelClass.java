package com.example.washingthecars;

public class ModelClass {
    //this is start of code for the recycler view
    private final int stationimage;
    private final int stationratng;
    private final String stationtitle;
    private final String stationdescription;
    private final String divider;

    public ModelClass(int stationimage, int stationratng, String stationtitle, String stationdescription, String divider){
        //this is the start of the code for the recycler view in the station list activity
        this.stationimage = stationimage;
        this.stationratng = stationratng;
        this.stationtitle = stationtitle;
        this.stationdescription = stationdescription;
        this.divider = divider;
    }


    public int getStationimage() {
        return stationimage;
    }

    public int getStationratng() {
        return stationratng;
    }

    public String getStationtitle() {
        return stationtitle;
    }

    public String getStationdescription() {
        return stationdescription;
    }

    public String getDivider() {
        return divider;
    }

    //this is the end of the code for the recycler view in the station list activity
}
