package com.example.washingthecars;

import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.content.pm.ActivityInfo;
import android.os.Bundle;
import android.util.Patterns;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

import com.google.android.material.textfield.TextInputLayout;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.FirebaseDatabase;

import java.util.Objects;

public class RegisterUser extends AppCompatActivity implements View.OnClickListener{

    TextInputLayout   editTextFullName, editTextPhonenumber, editTextEmail, editTextPassword, editTextUsername;


    private FirebaseAuth mAuth;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_register_user);


        mAuth = FirebaseAuth.getInstance();


        Button banner = findViewById(R.id.gotologin);
        banner.setOnClickListener(this);

        Button registerUser = findViewById(R.id.reg_btn);
        registerUser.setOnClickListener(this);

        editTextFullName = findViewById(R.id.reg_name);
        editTextPhonenumber = findViewById(R.id.reg_phoneNo);
        editTextEmail = findViewById(R.id.reg_email);
        editTextPassword = findViewById(R.id.reg_password);
        editTextUsername = findViewById(R.id.reg_username);
    }

    private void registerUser() {
        String email = Objects.requireNonNull(Objects.requireNonNull(editTextEmail.getEditText()).getText()).toString().trim();
        String password = Objects.requireNonNull(Objects.requireNonNull(editTextPassword.getEditText()).getText()).toString().trim();
        String fullName = Objects.requireNonNull(Objects.requireNonNull(editTextFullName.getEditText()).getText()).toString().trim();
        String phoneNumber = Objects.requireNonNull(Objects.requireNonNull(editTextPhonenumber.getEditText()).getText()).toString().trim();
        String  userName = Objects.requireNonNull(Objects.requireNonNull(editTextUsername.getEditText()).getText()).toString().trim();

        if (fullName.isEmpty()) {
            editTextFullName.setError("Full Name is required");
            editTextFullName.requestFocus();
            return;
        }
        if(userName.isEmpty()) {
            editTextUsername.setError("Username is required");
            editTextUsername.requestFocus();
            return;
        }
        if (phoneNumber.isEmpty()) {
            editTextPhonenumber.setError("Phone Number is Required");
            editTextPhonenumber.requestFocus();
            return;
        }
        if (email.isEmpty()) {
            editTextEmail.setError("Email is Required");
            editTextEmail.requestFocus();
            return;
        }
        if (!Patterns.EMAIL_ADDRESS.matcher(email).matches()) {
            editTextEmail.setError("Please provide valid email!");
            editTextEmail.requestFocus();
            return;
        }
        if (password.isEmpty()) {
            editTextPassword.setError("Password is Required");
            editTextPassword.requestFocus();
            return;

        }
        if (password.length() < 6) {
            editTextPassword.setError("Password should be 6 characters MIN");
            editTextPassword.requestFocus();
            return;
        }
        mAuth.createUserWithEmailAndPassword(email, password)
                .addOnCompleteListener(task -> {
                    if(task.isSuccessful()){
                        User user = new User(fullName, phoneNumber, email,password, userName);
                        FirebaseDatabase.getInstance().getReference("Users")
                                .child(Objects.requireNonNull(FirebaseAuth.getInstance().getCurrentUser()).getUid())
                                .setValue(user).addOnCompleteListener(task1 -> {
                                    if (task1.isSuccessful()) {
                                        Toast.makeText(RegisterUser.this, "User has been registered Successfully", Toast.LENGTH_SHORT).show();

                                    }
                                    else{
                                        Toast.makeText(RegisterUser.this, "Failed to Register!", Toast.LENGTH_LONG).show();
                                    }
                                });
                    }else
                        Toast.makeText(RegisterUser.this, "Failed to register!", Toast.LENGTH_LONG).show();

                });
    }

    @SuppressLint("NonConstantResourceId")
    @Override
    public void onClick(View view) {
        switch (view.getId()) {
            case R.id.gotologin:
                startActivity(new Intent(this, MainActivity.class));
                break;
            case R.id.reg_btn:
                registerUser();
                break;
        }

    }
}

