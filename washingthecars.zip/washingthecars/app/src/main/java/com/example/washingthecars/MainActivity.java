package com.example.washingthecars;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.ActivityInfo;
import android.os.Bundle;
import android.util.Patterns;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.android.material.textfield.TextInputLayout;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;

import java.util.Objects;

public class MainActivity extends AppCompatActivity implements View.OnClickListener{
    private static final String FILE_NAME = "myFile";
    TextInputLayout  editTextEmail, editTextPassword;
    Button signIn;
    Button gotoRegister, forgotPassword;
    CheckBox checkBox;
    FirebaseAuth mAuth;
    //start for double tap to exit app
    private long backPressedTime;
    private Toast backToast;
    //end for double tap to exit app
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);


        gotoRegister = findViewById(R.id.gotoregister);
        gotoRegister.setOnClickListener(this);

        signIn = findViewById(R.id.login);
        signIn.setOnClickListener(this);

        editTextPassword = findViewById(R.id.log_password);
        editTextEmail = findViewById(R.id.log_email);

        mAuth = FirebaseAuth.getInstance();
        forgotPassword = findViewById(R.id.forgotPassword);

        checkBox = findViewById(R.id.remember_me);
        SharedPreferences sharedPreferences = getSharedPreferences(FILE_NAME,MODE_PRIVATE);
        String email = sharedPreferences.getString("email","");
        String password = sharedPreferences.getString("password","");

        Objects.requireNonNull(editTextEmail.getEditText()).setText(email);
        Objects.requireNonNull(editTextPassword.getEditText()).setText(password);

        forgotPassword.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View view) {
                Intent intent = new Intent(MainActivity.this, ForgotPassword.class);
                startActivity(intent);
            }
        });
    }
    //start for double tap to exit app
    public void onBackPressed() {
        if(backPressedTime + 2000 > System.currentTimeMillis()) {
            backToast.cancel();
            super.onBackPressed();
            return;
        }else{
            backToast = Toast.makeText(getBaseContext(),"Press Back Again to Exit",Toast.LENGTH_SHORT);
            backToast.show();
        }
        backPressedTime = System.currentTimeMillis();
    }
    //end for double tap to exit app

    @Override
    public void onClick(View view) {
        switch (view.getId()) {
            case R.id.gotoregister:
                startActivity(new Intent(this, RegisterUser.class));
                break;
            case R.id.login:
                userLogin();
                break;
        }
    }

    private void userLogin() {
        String email = Objects.requireNonNull(Objects.requireNonNull(editTextEmail.getEditText()).getText()).toString().trim();
        String password = Objects.requireNonNull(Objects.requireNonNull(editTextPassword.getEditText()).getText()).toString().trim();

        if(email.isEmpty()){
            editTextEmail.setError("Email is Required");
            editTextEmail.requestFocus();
            return;
        }
        if(!Patterns.EMAIL_ADDRESS.matcher(email).matches()){
            editTextEmail.setError("Please Enter a Valid Email!");
            editTextEmail.requestFocus();
            return;
        }
        if(password.isEmpty()){
            editTextPassword.setError("Password is required");
            editTextPassword.requestFocus();
            return;
        }
        if(password.length() < 6){
            editTextPassword.setError("Min password length is 6 characters!");
            editTextPassword.requestFocus();
            return;
        }
        if(checkBox.isChecked()){
            StoredDataUsingSharedPref(email, password);
        }

        mAuth.signInWithEmailAndPassword(email, password).addOnCompleteListener(new OnCompleteListener<AuthResult>() {
            @Override
            public void onComplete(@NonNull Task<AuthResult> task) {

                if(task.isSuccessful()){
                    startActivity(new Intent(MainActivity.this,Stationlist.class));

                }
                else {
                    Toast.makeText(MainActivity.this, "Failed to login!",Toast.LENGTH_SHORT).show();
                }
            }
        });

    }

    private void StoredDataUsingSharedPref(String email, String password) {

        SharedPreferences.Editor editor = getSharedPreferences(FILE_NAME, MODE_PRIVATE).edit();
        editor.putString("email",email);
        editor.putString("password",password);
        editor.apply();
    }
}