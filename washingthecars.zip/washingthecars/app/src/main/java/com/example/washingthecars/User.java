package com.example.washingthecars;

public class User {
    public String fullName, age,email, password, username, phone;
    public User(){

    }
    public User(String fullName, String phone, String email, String password, String username){
        this.fullName = fullName;
        this.phone = phone;
        this.email = email;
        this.password = password;
        this.username = username;
    }
}
