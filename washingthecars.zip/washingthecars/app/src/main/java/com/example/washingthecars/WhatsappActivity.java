package com.example.washingthecars;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.content.pm.ActivityInfo;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.hbb20.CountryCodePicker;

public class WhatsappActivity extends AppCompatActivity {
    CountryCodePicker countryCodePicker;
    EditText phone , message;
    Button sendbtn;
    String messagestr, phonestr = "";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_whatsapp);

        countryCodePicker = findViewById(R.id.countryCode);
        phone = findViewById(R.id.phoneNo);
        message = findViewById(R.id.message);
        sendbtn = findViewById(R.id.sendbtn);

        sendbtn.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View view) {
                messagestr = message.getText().toString();
                phonestr = phone.getText().toString();
                if(!messagestr.isEmpty() && !phonestr.isEmpty()) {
                    countryCodePicker.registerCarrierNumberEditText(phone);
                    phonestr = countryCodePicker.getFullNumber();
                    if(isWhatsappInstalled()){
                        Intent i = new Intent(Intent.ACTION_VIEW, Uri.parse("https://api.whatsapp.com/send?phone="+ phonestr+
                                "&text="+ messagestr));
                        startActivity(i);
                        message.setText("");
                        phone.setText("");
                    }else{
                        Toast.makeText(WhatsappActivity.this, "Whatsapp is not installed", Toast.LENGTH_SHORT).show();
                    }

                }else{
                    Toast.makeText(WhatsappActivity.this, "Please fill in Phone No. and message it can't ne empty", Toast.LENGTH_LONG).show();
                }

            }
        });
    }
    private boolean isWhatsappInstalled(){
        PackageManager packageManager = getPackageManager();
        boolean whatsappinstalled;
        try{
            packageManager.getPackageInfo("com.whatsapp",PackageManager.GET_ACTIVITIES);
            whatsappinstalled = true;

        }catch(PackageManager.NameNotFoundException e){
            whatsappinstalled = false;
        }
        return whatsappinstalled;
    }
}